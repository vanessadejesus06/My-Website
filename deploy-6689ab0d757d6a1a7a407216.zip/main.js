var typed = new Typed(".input", {
    strings: [" Web Designer", " Photographer"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
})